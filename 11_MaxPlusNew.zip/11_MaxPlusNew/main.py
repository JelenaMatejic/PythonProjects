from application import Application
from automaton import Automaton
import tkinter as tk

root = tk.Tk()
app = Application(root)
root.mainloop()
